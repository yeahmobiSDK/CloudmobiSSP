//
//  CTADBannerCustomEvent.m
//  MoPubSampleApp
//
//  Created by Mirinda on 17/7/7.
//  Copyright © 2017年 MoPub. All rights reserved.
//

#import "CTADBannerCustomEvent.h"
#import <CTSDK/CTSDK.h>

@interface CTADBannerCustomEvent()
@property (nonatomic,strong)CTBanner* ctBanner;
@end

@implementation CTADBannerCustomEvent


- (BOOL)enableAutomaticImpressionAndClickTracking
{
    return NO;
}

- (void)requestAdWithSize:(CGSize)size customEventInfo:(NSDictionary *)info
{
    NSString *slotid = [info objectForKey:@"slotid"];
    CTService* manager = [CTService shareManager];
    [manager loadRequestGetCTSDKConfigBySlot_id:slotid];
    [manager getBannerADswithSlotId:slotid delegate:self frame:CGRectMake(0, 0, size.width, size.height) needCloseButton:YES isTest:NO success:^(UIView *bannerView) {
        self.ctBanner =(CTBanner*)bannerView;
        if ([self.delegate respondsToSelector:@selector(bannerCustomEvent:didLoadAd:)])
        {
            [self.delegate bannerCustomEvent:self didLoadAd:bannerView];
        }
        
        if ([self.delegate respondsToSelector:@selector(trackImpression)])
        {
            [self.delegate trackImpression];
        }

    } failure:^(NSError *error) {
        if ([self.delegate respondsToSelector:@selector(bannerCustomEvent:didFailToLoadAdWithError:)])
        {
            [self.delegate bannerCustomEvent:self didFailToLoadAdWithError:error];
        }
    }];
}

- (void)dealloc
{
    if (self.ctBanner)
    {
        [(UIView*)self.ctBanner removeFromSuperview];
    }
}

#pragma mark FBAdViewDelegate methods
-(void)CTBannerDidClick:(CTBanner*)banner
{
    
    if ([self.delegate respondsToSelector:@selector(trackClick)])
    {
        [self.delegate trackClick];
    }
    
    if ([self.delegate respondsToSelector:@selector(bannerCustomEventWillBeginAction:)])
    {
        [self.delegate bannerCustomEventWillBeginAction:self];
    }
    
}

-(void)CTBannerWillLeaveApplication:(CTBanner*)banner
{
    if ([self.delegate respondsToSelector:@selector(bannerCustomEventWillLeaveApplication:)])
    {
        [self.delegate bannerCustomEventWillLeaveApplication:self];
    }
}

@end
