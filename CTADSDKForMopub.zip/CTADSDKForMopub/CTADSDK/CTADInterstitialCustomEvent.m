//
//  CTADInterstitialCustomEvent.m
//  MoPubSampleApp
//
//  Created by Mirinda on 17/7/10.
//  Copyright © 2017年 MoPub. All rights reserved.
//

#import "CTADInterstitialCustomEvent.h"
#import <CTSDK/CTSDK.h>

@implementation CTADInterstitialCustomEvent

- (void)requestInterstitialWithCustomEventInfo:(NSDictionary *)info
{
    NSString *slotid = [info objectForKey:@"slotid"];
    CTService* manager = [CTService shareManager];
    [manager loadRequestGetCTSDKConfigBySlot_id:slotid];
    [manager preloadInterstitialAdWithSlotId:slotid delegate:self isTest:NO];
}


- (void)showInterstitialFromRootViewController:(UIViewController *)rootViewController
{
    CTService* manager = [CTService shareManager];
    [manager interstitialAdShow];
    
    if ([self.delegate respondsToSelector:@selector(trackImpression)])
    {
        [self.delegate trackImpression];
    }
}

- (void)dealloc
{
    
}

#pragma mark FBInterstitialAdDelegate methods

-(void)CTADInterstitialGetAdSuccess
{
    if ([self.delegate respondsToSelector:@selector(interstitialCustomEvent:didLoadAd:)])
    {
        [self.delegate interstitialCustomEvent:self didLoadAd:nil];
    }
}

-(void)CTADInterstitialGetAdFailed:(NSError *)error
{
    if ([self.delegate respondsToSelector:@selector(interstitialCustomEvent:didFailToLoadAdWithError:)])
    {
        [self.delegate interstitialCustomEvent:self didFailToLoadAdWithError:error];
    }
}

-(void)CTADInterstitialDidClick
{
    if ([self.delegate respondsToSelector:@selector(trackClick)])
    {
        [self.delegate trackClick];
    }
    
    if ([self.delegate respondsToSelector:@selector(interstitialCustomEventDidReceiveTapEvent:)])
    {
        [self.delegate interstitialCustomEventDidReceiveTapEvent:self];
    }
    
}

- (void)CTADInterstitialDidIntoLandingPage
{
    if ([self.delegate respondsToSelector:@selector(interstitialCustomEventWillLeaveApplication:)])
    {
        [self.delegate interstitialCustomEventWillLeaveApplication:self];
    }
}

- (void)CTADInterstitialJumpFailed
{
   
}

-(void)CTADInterstitialAdShowFailed:(NSError *)error
{
    
}

-(void)CTADInterstitialClosed
{
    if ([self.delegate respondsToSelector:@selector(interstitialCustomEventWillDisappear:)])
    {
        [self.delegate interstitialCustomEventWillDisappear:self];
    }
    
    if ([self.delegate respondsToSelector:@selector(interstitialCustomEventDidDisappear:)])
    {
        [self.delegate interstitialCustomEventDidDisappear:self];
    }
}

@end
