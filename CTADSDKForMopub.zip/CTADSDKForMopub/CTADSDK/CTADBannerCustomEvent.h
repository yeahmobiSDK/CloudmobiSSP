//
//  CTADBannerCustomEvent.h
//  MoPubSampleApp
//
//  Created by Mirinda on 17/7/7.
//  Copyright © 2017年 MoPub. All rights reserved.
//

#import "MPBannerCustomEvent.h"
#import <CTSDK/CTADExternalDelegate.h>

@interface CTADBannerCustomEvent : MPBannerCustomEvent<CTBannerDelegate>

@end
